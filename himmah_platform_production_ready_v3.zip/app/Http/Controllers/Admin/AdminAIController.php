<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\AIUsageLog;
use App\Services\AIService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class AdminAIController extends Controller
{
    protected $aiService;

    public function __construct(AIService $aiService)
    {
        $this->aiService = $aiService;
    }

    /**
     * توليد تقرير ذكي عن أداء المنصة
     */
    public function generatePlatformReport()
    {
        // تجميع بيانات إحصائية
        $stats = [
            'total_courses' => Course::count(),
            'total_ai_requests' => AIUsageLog::count(),
            'most_active_courses' => AIUsageLog::select('course_id', DB::raw('count(*) as total'))
                ->with('course:id,title')
                ->groupBy('course_id')
                ->orderBy('total', 'desc')
                ->limit(5)
                ->get(),
        ];

        $systemMessage = "أنت محلل بيانات خبير. قم بتحليل الإحصائيات التالية لمنصة تعليمية وقدم توصيات لتحسين الأداء وزيادة تفاعل الطلاب.";
        
        $prompt = json_encode($stats);

        $response = $this->aiService->ask(
            $prompt, 
            $systemMessage, 
            Auth::id(), 
            ['feature' => 'admin_report']
        );

        return view('admin.ai.report', compact('response', 'stats'));
    }
}

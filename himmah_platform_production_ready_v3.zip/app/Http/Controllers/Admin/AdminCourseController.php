<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use App\Services\ImageService;
use App\Services\VideoService;
use Illuminate\Http\Request;

class AdminCourseController extends Controller
{
    protected $imageService;
    protected $videoService;

    public function __construct(ImageService $imageService, VideoService $videoService)
    {
        $this->imageService = $imageService;
        $this->videoService = $videoService;
    }

    public function index()
    {
        $courses = Course::with(['teacher', 'university'])->latest()->paginate(20);
        foreach ($courses as $course) {
            $course->thumbnail_url = $this->imageService->getUrl($course->thumbnail);
        }
        return view('admin.courses.index', compact('courses'));
    }

    /**
     * إضافة درس جديد مع فيديو عبر النظام الجديد
     */
    public function storeLesson(Request $request, Course $course)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'video_path' => 'required|string', // المسار المرفوع لـ Wasabi
        ]);

        $lesson = $course->lessons()->create([
            'title' => $request->title,
            'video_path' => $request->video_path,
            'video_platform' => 'wasabi',
            'status' => 'processing'
        ]);

        // بدء معالجة HLS في الخلفية
        // dispatch(new \App\Jobs\ProcessVideoHLS($lesson));

        return back()->with('success', 'تم إضافة الدرس وبدء معالجة الفيديو');
    }

    public function destroy(Course $course)
    {
        if ($course->thumbnail) {
            $this->imageService->deleteImage($course->thumbnail);
        }
        $course->delete();
        return back()->with('success', 'تم حذف الكورس بنجاح');
    }
}

<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\User;
use Illuminate\Http\Request;

class AdminEnrollmentController extends Controller
{
    public function index(Course $course)
    {
        $this->authorize('viewList', [EnrollmentPolicy::class, $course]);
        
        $students = $course->students()->paginate(20);
        return view('admin.enrollments.index', compact('course', 'students'));
    }

    public function updateStatus(Request $request, Course $course, User $student)
    {
        $this->authorize('manage', [EnrollmentPolicy::class, $course]);

        $validated = $request->validate([
            'status' => 'required|in:active,suspended,expired',
            'subscription_end' => 'nullable|date'
        ]);

        $course->students()->updateExistingPivot($student->id, [
            'status' => $validated['status'],
            'subscription_end' => $validated['subscription_end'] ?? $student->pivot->subscription_end
        ]);

        return back()->with('success', 'تم تحديث حالة الاشتراك بنجاح.');
    }

    public function enroll(Request $request, Course $course)
    {
        $this->authorize('manage', [EnrollmentPolicy::class, $course]);

        $validated = $request->validate([
            'user_id' => 'required|exists:users,id',
            'duration_months' => 'required|integer|min:1'
        ]);

        $course->students()->syncWithoutDetaching([
            $validated['user_id'] => [
                'subscription_start' => now(),
                'subscription_end' => now()->addMonths($validated['duration_months']),
                'status' => 'active'
            ]
        ]);

        return back()->with('success', 'تم تسجيل الطالب في الدورة بنجاح.');
    }
}

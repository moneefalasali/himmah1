<?php
namespace App\Http\Controllers;

use App\Models\ChatRoom;
use App\Models\Course;
use App\Services\ChatService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ChatController extends Controller
{
    protected $chatService;

    public function __construct(ChatService $chatService)
    {
        $this->chatService = $chatService;
    }

    /**
     * عرض غرفة الدردشة بناءً على النوع
     */
    public function show(ChatRoom $room)
    {
        $user = Auth::user();

        // 1. منطق دردشة الخدمات (طالب + إدارة فقط)
        if ($room->type === 'service') {
            if (!$user->isAdmin() && $room->user_id !== $user->id) {
                abort(403, 'هذه الدردشة خاصة بالدعم الفني فقط.');
            }
        } 
        // 2. منطق دردشة الكورسات (طلاب الكورس + المعلم + الإدارة)
        else if ($room->course_id) {
            $course = $room->course;
            $isStudent = $user->isEnrolledIn($course);
            $isTeacher = ($course->user_id === $user->id);
            $isAdmin = $user->isAdmin();

            if (!$isStudent && !$isTeacher && !$isAdmin) {
                abort(403, 'يجب أن تكون مسجلاً في الكورس للوصول للدردشة.');
            }
        }

        return view('chat.show', [
            'room' => $room,
            'messages' => $this->chatService->getRoomMessages($room->id)
        ]);
    }

    /**
     * فتح أو إنشاء دردشة خدمات مع الإدارة
     */
    public function adminChat()
    {
        $admin = \App\Models\User::where("role", "admin")->first();
        $room = ChatRoom::firstOrCreate([
            "user_id" => auth()->id(),
            "type" => "service"
        ], [
            "admin_id" => $admin->id,
            "name" => "الدعم الفني والخدمات"
        ]);

        return redirect()->route("chat.show", $room->id);
    }

    /**
     * فتح أو إنشاء دردشة كورس
     */
    public function courseChat(Course $course)
    {
        $room = ChatRoom::firstOrCreate([
            'course_id' => $course->id,
            'type' => 'course'
        ], [
            'name' => "دردشة كورس: " . $course->title
        ]);

        return redirect()->route("chat.show", $room->id);
    }
}

<?php
namespace App\Http\Controllers;
use App\Models\Course;
use App\Models\Category;
use App\Models\Subject;
use App\Models\University;
use Illuminate\Http\Request;
class CourseController extends Controller
{
    public function index(Request $request)
    {
        $query = Course::query()->where('status', 'active');
        if ($request->filled('classification')) {
            if ($request->classification === 'university') {
                $query->whereNotNull('university_id');
                if ($request->filled('university_id')) {
                    $query->where('university_id', $request->university_id);
                }
                if ($request->filled('subject_id')) {
                    $query->where('subject_id', $request->subject_id);
                }
            } else {
                $query->whereNull('university_id');
            }
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('search')) {
            $query->where('title', 'like', '%' . $request->search . '%');
        }
        $courses = $query->with(['university', 'subject', 'teacher'])->latest()->paginate(12);
        $universities = University::all();

        if ($request->ajax()) {
            return view('courses._course_list', compact('courses'))->render();
        }

        return view('courses.index', compact('courses', 'universities'));
    }
    public function getUniversitySubjects(University $university)
    {
        return response()->json($university->subjects);
    }
    public function show(Course $course)
    {
        $course->load(['university', 'subject', 'teacher', 'sections.lessons']);
        return view('courses.show', compact('course'));
    }
}

<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceType;

class ServiceController extends Controller
{
    public function index()
    {
        // عرض الخدمات المتاحة فقط
        $services = ServiceType::where('is_active', true)->get();
        return view('services.index', compact('services'));
    }
}

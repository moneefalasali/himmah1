<?php
namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\University;
use App\Models\Subject;
use App\Services\ImageService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TeacherCourseController extends Controller
{
    protected $imageService;

    public function __construct(ImageService $imageService)
    {
        $this->imageService = $imageService;
    }

    public function index()
    {
        $courses = Course::where('user_id', Auth::id())->latest()->paginate(10);
        foreach ($courses as $course) {
            $course->thumbnail_url = $this->imageService->getUrl($course->thumbnail);
        }
        return view('teacher.courses.index', compact('courses'));
    }

    public function create()
    {
        $universities = University::all();
        return view('teacher.courses.create', compact('universities'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'classification' => 'required|in:university,general',
            'thumbnail' => 'required|image|max:2048',
            'type' => 'required|in:recorded,online',
        ]);

        $data = $request->all();
        $data['user_id'] = Auth::id();

        if ($request->hasFile('thumbnail')) {
            $data['thumbnail'] = $this->imageService->uploadImage($request->file('thumbnail'), 'courses');
        }

        Course::create($data);

        return redirect()->route('teacher.courses.index')->with('success', 'تم إنشاء الكورس بنجاح');
    }

    public function edit(Course $course)
    {
        $this->authorize('update', $course);
        $universities = University::all();
        $course->thumbnail_url = $this->imageService->getUrl($course->thumbnail);
        return view('teacher.courses.edit', compact('course', 'universities'));
    }

    public function update(Request $request, Course $course)
    {
        $this->authorize('update', $course);
        
        $request->validate([
            'title' => 'required|string|max:255',
            'thumbnail' => 'nullable|image|max:2048',
        ]);

        $data = $request->all();

        if ($request->hasFile('thumbnail')) {
            if ($course->thumbnail) {
                $this->imageService->deleteImage($course->thumbnail);
            }
            $data['thumbnail'] = $this->imageService->uploadImage($request->file('thumbnail'), 'courses');
        }

        $course->update($data);

        return redirect()->route('teacher.courses.index')->with('success', 'تم تحديث الكورس بنجاح');
    }
}

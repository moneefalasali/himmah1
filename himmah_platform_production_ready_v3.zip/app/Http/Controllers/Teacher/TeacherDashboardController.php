<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Sale;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TeacherDashboardController extends Controller
{
    public function index()
    {
        $teacher = Auth::user();

        $stats = [
            'courses_count' => Course::where('user_id', $teacher->id)->count(),
            'total_students' => Sale::where('teacher_id', $teacher->id)->distinct('user_id')->count(),
            'total_earnings' => Sale::where('teacher_id', $teacher->id)->sum('teacher_commission'),
            'recent_sales_count' => Sale::where('teacher_id', $teacher->id)->where('created_at', '>=', now()->subDays(30))->count(),
        ];

        // بيانات الرسم البياني للمبيعات (آخر 30 يوم)
        $chartData = Sale::where('teacher_id', $teacher->id)
            ->where('created_at', '>=', now()->subDays(30))
            ->select(DB::raw('DATE(created_at) as date'), DB::raw('sum(teacher_commission) as earnings'))
            ->groupBy('date')
            ->orderBy('date')
            ->get();

        $recentCourses = Course::where('user_id', $teacher->id)
            ->withCount('lessons')
            ->latest()
            ->take(5)
            ->get();

        return view('teacher.dashboard', compact('stats', 'chartData', 'recentCourses'));
    }
}

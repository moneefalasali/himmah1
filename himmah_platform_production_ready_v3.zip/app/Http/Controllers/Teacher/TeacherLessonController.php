<?php
namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Lesson;
use App\Jobs\ProcessVideoHLS;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class TeacherLessonController extends Controller
{
    public function store(Request $request, Course $course)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'video' => 'required|file|mimetypes:video/mp4,video/quicktime|max:512000', // 500MB
        ]);

        // 1. رفع الفيديو الخام إلى Wasabi
        $path = $request->file('video')->store('raw_videos', 's3');

        // 2. إنشاء سجل الدرس
        $lesson = $course->lessons()->create([
            'title' => $request->title,
            'description' => $request->description,
            'video_path' => $path,
            'video_platform' => 'wasabi',
            'status' => 'processing'
        ]);

        // 3. إرسال مهمة معالجة HLS للخلفية
        ProcessVideoHLS::dispatch($lesson);

        return back()->with('success', 'تم رفع الفيديو بنجاح، جاري المعالجة...');
    }
}

<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Models\Sale;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TeacherSalesController extends Controller
{
    public function index(Request $request)
    {
        $teacher = Auth::user();

        // إحصائيات عامة للمعلم
        $stats = [
            'total_revenue' => Sale::where('teacher_id', $teacher->id)->sum('amount'),
            'teacher_earnings' => Sale::where('teacher_id', $teacher->id)->sum('teacher_commission'),
            'total_sales_count' => Sale::where('teacher_id', $teacher->id)->count(),
        ];

        // المبيعات حسب الدورة
        $salesByCourse = Sale::where('teacher_id', $teacher->id)
            ->select('course_id', DB::raw('count(*) as total_sales'), DB::raw('sum(amount) as total_amount'), DB::raw('sum(teacher_commission) as teacher_profit'))
            ->with('course:id,title')
            ->groupBy('course_id')
            ->get();

        // قائمة المبيعات الأخيرة
        $recentSales = Sale::where('teacher_id', $teacher->id)
            ->with(['course:id,title', 'student:id,name,email'])
            ->latest()
            ->paginate(15);

        return view('teacher.sales.index', compact('stats', 'salesByCourse', 'recentSales'));
    }
}

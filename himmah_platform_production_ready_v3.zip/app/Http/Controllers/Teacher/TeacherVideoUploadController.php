<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;
use App\Services\VideoService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TeacherVideoUploadController extends Controller
{
    protected $videoService;

    public function __construct(VideoService $videoService)
    {
        $this->videoService = $videoService;
    }

    /**
     * معالجة رفع الفيديو بالـ Chunks للمعلم
     */
    public function upload(Request $request)
    {
        $request->validate([
            'file' => 'required|file',
            'filename' => 'required|string',
            'chunkIndex' => 'required|integer',
            'totalChunks' => 'required|integer',
        ]);

        $file = $request->file('file');
        $filename = $request->filename;
        $chunkIndex = $request->chunkIndex;
        $totalChunks = $request->totalChunks;

        $result = $this->videoService->handleChunkUpload($file, $filename, $chunkIndex, $totalChunks);

        if ($result) {
            // تم اكتمال الرفع وتجميع الملف محلياً
            // نرفع الملف الآن إلى Wasabi
            $wasabiPath = $this->videoService->uploadRawToWasabi($result, Auth::id() . '_' . uniqid());
            
            return response()->json([
                'success' => true,
                'video_path' => $wasabiPath
            ]);
        }

        return response()->json(['success' => true, 'message' => 'Chunk uploaded']);
    }
}

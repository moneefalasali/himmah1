<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class Course extends Model
{
    use HasFactory;
    protected  = [
        'user_id', 'title', 'description', 'status', 'total_lessons', 'university_id', 'subject_id', 'type', 'price', 'instructor_name', 'image'
    ];
    public function teacher()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function lessons()
    {
        return $this->hasMany(Lesson::class);
    }
    public function sections()
    {
        return $this->hasMany(Section::class);
    }
    public function sales()
    {
        return $this->hasMany(Sale::class);
    }
    public function university()
    {
        return $this->belongsTo(University::class);
    }
    public function subject()
    {
        return $this->belongsTo(Subject::class);
    }
    public function scopePublished($query)
    {
        return $query->where("status", "active");
    }
}

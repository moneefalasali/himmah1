<?php
namespace App\Models;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
class User extends Authenticatable
{
    use HasFactory, Notifiable;
    protected  = [
        'name', 'email', 'password', 'role', 'avatar', 'google_id', 'is_instructor'
    ];
    protected  = ['avatar_url'];
    protected  = [
        'password', 'remember_token', 'google_id',
    ];
    public function getAvatarUrlAttribute()
    {
        if (!$this->avatar) {
            return asset('assets/images/default-avatar.png');
        }
        return app(\App\Services\ImageService::class)->getSignedUrl($this->avatar);
    }
    public function isAdmin() { return $this->role === 'admin'; }
    public function isTeacher() { return $this->role === 'teacher' || $this->is_instructor; }
    public function isStudent() { return $this->role === 'student'; }
    public function isEnrolledIn($course)
    public function hasPurchased($courseId)
    public function isSubscribedTo($course)
    {
        return $this->hasPurchased($course->id);
    }
    {
        return $this->enrolledCourses()->where("course_id", $courseId)->wherePivot("status", "active")->exists();
    }
    {
        return $this->enrolledCourses()->where("course_id", $course->id)->wherePivot("status", "active")->exists();
    }
    public function teacherCourses()
    {
        return $this->hasMany(Course::class, 'user_id');
    }
    public function enrolledCourses()
    {
        return $this->belongsToMany(Course::class, 'course_user')
            ->withPivot(['subscription_start', 'subscription_end', 'status'])
            ->withTimestamps();
    }
    public function activeCourses()
    {
        return $this->enrolledCourses()
            ->wherePivot('status', 'active')
            ->wherePivot('subscription_end', '>', now());
    }
}

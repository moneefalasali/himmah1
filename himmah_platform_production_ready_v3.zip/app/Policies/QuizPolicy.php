<?php

namespace App\Policies;

use App\Models\Quiz;
use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;

class QuizPolicy
{
    use HandlesAuthorization;

    /**
     * المعلم يمكنه رؤية كويزات دوراته فقط، الإدارة ترى الكل.
     */
    public function viewAny(User $user)
    {
        return $user->isAdmin() || $user->isTeacher();
    }

    /**
     * التحقق مما إذا كان المستخدم يملك الكويز (عبر الدورة).
     */
    public function view(User $user, Quiz $quiz)
    {
        if ($user->isAdmin()) return true;
        return $user->id === $quiz->course->user_id;
    }

    public function create(User $user)
    {
        return $user->isAdmin() || $user->isTeacher();
    }

    public function update(User $user, Quiz $quiz)
    {
        if ($user->isAdmin()) return true;
        return $user->id === $quiz->course->user_id;
    }

    public function delete(User $user, Quiz $quiz)
    {
        if ($user->isAdmin()) return true;
        return $user->id === $quiz->course->user_id;
    }

    /**
     * الطالب يمكنه حل الكويز إذا كان مسجلاً في الدورة والكويز منشور.
     */
    public function take(User $user, Quiz $quiz)
    {
        if ($quiz->status !== 'published') return false;
        
        // التحقق من تسجيل الطالب في الدورة (بناءً على منطق المنصة الحالي)
        // نفترض وجود علاقة أو جدول مبيعات/اشتراكات
        return $user->courses()->where('course_id', $quiz->course_id)->exists() || $user->isAdmin();
    }
}

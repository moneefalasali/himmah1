<?php

namespace App\Services;

use OpenAI;
use Illuminate\Support\Facades\Log;
use App\Models\AIUsageLog;

class AIService
{
    protected $client;
    protected $model;

    public function __construct()
    {
        $apiKey = config('services.openai.api_key');
        $this->client = OpenAI::client($apiKey);
        $this->model = config('services.openai.model', 'gpt-4o-mini');
    }

    /**
     * إرسال طلب عام للذكاء الاصطناعي مع تسجيل الاستهلاك
     */
    public function ask($prompt, $systemMessage = "أنت مساعد ذكي في منصة تعليمية.", $userId = null, $context = [])
    {
        try {
            $response = $this->client->chat()->create([
                'model' => $this->model,
                'messages' => [
                    ['role' => 'system', 'content' => $systemMessage],
                    ['role' => 'user', 'content' => $prompt],
                ],
                'temperature' => 0.7,
            ]);

            $answer = $response->choices[0]->message->content;
            $tokens = $response->usage->totalTokens;

            // تسجيل الاستهلاك
            if ($userId) {
                $this->logUsage($userId, $tokens, $context);
            }

            return $answer;

        } catch (\Exception $e) {
            Log::error("AI Service Error: " . $e->getMessage());
            throw new \Exception("عذراً، حدث خطأ في معالجة طلبك عبر الذكاء الاصطناعي.");
        }
    }

    /**
     * تسجيل استهلاك التوكنات
     */
    protected function logUsage($userId, $tokens, $context)
    {
        AIUsageLog::create([
            'user_id' => $userId,
            'tokens_used' => $tokens,
            'feature' => $context['feature'] ?? 'general',
            'course_id' => $context['course_id'] ?? null,
            'metadata' => json_encode($context['metadata'] ?? []),
        ]);
    }
}

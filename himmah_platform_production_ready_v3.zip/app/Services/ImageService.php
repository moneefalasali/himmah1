<?php
namespace App\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;

class ImageService
{
    protected $disk;

    public function __construct()
    {
        // استخدام ديسك s3 (Wasabi) حصرياً كما هو مطلوب
        $this->disk = Storage::disk('s3');
    }

    /**
     * رفع الصورة إلى Wasabi بشكل Private
     */
    public function uploadImage(UploadedFile $file, $folder = 'general')
    {
        $filename = Str::random(40) . '.' . $file->getClientOriginalExtension();
        $path = "images/{$folder}/{$filename}";
        
        $stream = fopen($file->getRealPath(), 'r+');
        $this->disk->put($path, $stream, [
            'visibility' => 'private',
            'ContentType' => $file->getMimeType()
        ]);
        
        if (is_resource($stream)) {
            fclose($stream);
        }
        return $path;
    }

    /**
     * توليد رابط موقع (Signed URL) للصورة لضمان الحماية
     */
    public function getUrl($path, $expiresInMinutes = 60)
    {
        if (!$path) return asset('images/default-placeholder.png');

        if (Str::startsWith($path, ['http://', 'https://'])) {
            return $path;
        }

        try {
            return $this->disk->temporaryUrl(
                $path,
                now()->addMinutes($expiresInMinutes)
            );
        } catch (\Exception $e) {
            \Log::error("Error generating signed URL: " . $e->getMessage());
            return asset('images/default-placeholder.png');
        }
    }

    public function deleteImage($path)
    {
        if ($path && $this->disk->exists($path)) {
            return $this->disk->delete($path);
        }
        return false;
    }
}

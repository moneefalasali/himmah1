<?php

namespace App\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Http\UploadedFile;
use App\Models\Lesson;

class VideoService
{
    protected $disk;

    public function __construct()
    {
        $this->disk = Storage::disk('wasabi');
    }

    /**
     * Handle chunked upload
     */
    public function handleChunkUpload(UploadedFile $file, $filename, $chunkIndex, $totalChunks)
    {
        $tempPath = storage_path('app/temp/uploads/' . $filename);
        
        if (!file_exists(dirname($tempPath))) {
            mkdir(dirname($tempPath), 0777, true);
        }

        $out = fopen("{$tempPath}.part{$chunkIndex}", "wb");
        fwrite($out, file_get_contents($file->getRealPath()));
        fclose($out);

        if ($chunkIndex == $totalChunks - 1) {
            return $this->assembleChunks($tempPath, $totalChunks, $filename);
        }

        return false;
    }

    protected function assembleChunks($tempPath, $totalChunks, $filename)
    {
        $finalPath = storage_path('app/temp/uploads/' . $filename);
        $fp = fopen($finalPath, "wb");

        for ($i = 0; $i < $totalChunks; $i++) {
            $chunkFile = "{$tempPath}.part{$i}";
            $chunkContent = file_get_contents($chunkFile);
            fwrite($fp, $chunkContent);
            unlink($chunkFile);
        }

        fclose($fp);
        return $finalPath;
    }

    /**
     * Upload raw video to Wasabi
     */
    public function uploadRawToWasabi($localPath, $lessonId)
    {
        $filename = 'raw/' . $lessonId . '_' . time() . '.mp4';
        $stream = fopen($localPath, 'r+');
        
        $this->disk->put($filename, $stream, 'private');
        
        if (is_resource($stream)) {
            fclose($stream);
        }
        
        unlink($localPath);
        
        return $filename;
    }

    /**
     * Generate Signed URL for HLS Playlist
     */
    public function getSignedUrl($path, $expiresInMinutes = 10)
    {
        return $this->disk->temporaryUrl(
            $path,
            now()->addMinutes($expiresInMinutes)
        );
    }
}

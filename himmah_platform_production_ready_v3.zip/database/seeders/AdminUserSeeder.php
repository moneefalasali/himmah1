<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        // الأدمن
        User::create([
            'name' => 'مدير النظام',
            'email' => 'admin@himmah.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
            'phone' => '0501234567',
        ]);

        // المعلمون
        User::create([
            'name' => 'د. أحمد سعيد',
            'email' => 'teacher@himmah.com',
            'password' => Hash::make('teacher123'),
            'role' => 'teacher',
            'phone' => '0509876543',
        ]);

        User::create([
            'name' => 'أ. علي حسن',
            'email' => 'ali_teacher@himmah.com',
            'password' => Hash::make('teacher123'),
            'role' => 'teacher',
            'phone' => '0504444444',
        ]);

        // الطلاب
        User::create([
            'name' => 'محمد أحمد',
            'email' => 'student@himmah.com',
            'password' => Hash::make('student123'),
            'role' => 'student',
            'phone' => '0507654321',
        ]);
    }
}

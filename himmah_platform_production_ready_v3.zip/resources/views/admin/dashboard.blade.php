@extends('layouts.admin')

@section('content')
<div class="p-6 bg-gray-50 min-h-screen">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">لوحة تحكم الإدارة</h1>
        <p class="text-gray-600">نظرة عامة على أداء المنصة والعمليات الحالية.</p>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fas fa-users"></i>
                </div>
                <span class="text-green-500 text-sm font-bold">+12%</span>
            </div>
            <h3 class="text-gray-500 text-sm font-medium">إجمالي الطلاب</h3>
            <p class="text-2xl font-bold text-gray-800">{{ $totalStudents ?? 0 }}</p>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fas fa-book"></i>
                </div>
                <span class="text-green-500 text-sm font-bold">+5%</span>
            </div>
            <h3 class="text-gray-500 text-sm font-medium">الكورسات النشطة</h3>
            <p class="text-2xl font-bold text-gray-800">{{ $totalCourses ?? 0 }}</p>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-purple-100 text-purple-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <span class="text-gray-400 text-sm font-bold">0%</span>
            </div>
            <h3 class="text-gray-500 text-sm font-medium">إجمالي المعلمين</h3>
            <p class="text-2xl font-bold text-gray-800">{{ $totalTeachers ?? 0 }}</p>
        </div>

        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div class="flex items-center justify-between mb-4">
                <div class="w-12 h-12 bg-yellow-100 text-yellow-600 rounded-xl flex items-center justify-center text-xl">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <span class="text-red-500 text-sm font-bold">-2%</span>
            </div>
            <h3 class="text-gray-500 text-sm font-medium">إجمالي المبيعات</h3>
            <p class="text-2xl font-bold text-gray-800">{{ $totalSales ?? 0 }} ريال</p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Recent Activities -->
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-lg font-bold mb-6 border-b pb-4">آخر النشاطات</h3>
            <div class="space-y-6">
                @forelse($recentActivities ?? [] as $activity)
                    <div class="flex items-start">
                        <div class="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-4"></div>
                        <div>
                            <p class="text-sm text-gray-800 font-medium">{{ $activity->description }}</p>
                            <p class="text-xs text-gray-500">{{ $activity->created_at->diffForHumans() }}</p>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500 text-sm">لا توجد نشاطات حديثة.</p>
                @endforelse
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-lg font-bold mb-6 border-b pb-4">إجراءات سريعة</h3>
            <div class="grid grid-cols-2 gap-4">
                <a href="{{ route('admin.courses.create') }}" class="p-4 bg-blue-50 text-blue-700 rounded-xl hover:bg-blue-100 transition text-center">
                    <i class="fas fa-plus-circle mb-2 block text-xl"></i>
                    <span class="text-sm font-bold">إضافة كورس</span>
                </a>
                <a href="{{ route('admin.users.index') }}" class="p-4 bg-green-50 text-green-700 rounded-xl hover:bg-green-100 transition text-center">
                    <i class="fas fa-user-plus mb-2 block text-xl"></i>
                    <span class="text-sm font-bold">إدارة المستخدمين</span>
                </a>
                <a href="{{ route('admin.customer-chats.index') }}" class="p-4 bg-purple-50 text-purple-700 rounded-xl hover:bg-purple-100 transition text-center">
                    <i class="fas fa-comments mb-2 block text-xl"></i>
                    <span class="text-sm font-bold">دردشات العملاء</span>
                </a>
                <a href="{{ route('admin.ai.reports') }}" class="p-4 bg-yellow-50 text-yellow-700 rounded-xl hover:bg-yellow-100 transition text-center">
                    <i class="fas fa-chart-bar mb-2 block text-xl"></i>
                    <span class="text-sm font-bold">تقارير الـ AI</span>
                </a>
            </div>
        </div>
    </div>
</div>
@endsection

@extends('layouts.app')

@section('content')
<div class="container mx-auto p-4 h-screen flex flex-col" x-data="chatApp()">
    <div class="bg-white shadow-lg rounded-lg flex-1 flex flex-col overflow-hidden">
        <!-- Header -->
        <div class="p-4 border-b bg-blue-600 text-white flex justify-between items-center">
            <div class="flex items-center">
                @if($room->type === 'course' && $room->course)
                    <img src="{{ $room->course->thumbnail_url }}" class="w-10 h-10 rounded-full mr-3 border-2 border-white">
                @else
                    <div class="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center mr-3 border-2 border-white">
                        <i class="fas fa-headset"></i>
                    </div>
                @endif
                <div>
                    <h2 class="font-bold">{{ $room->name }}</h2>
                    <p class="text-xs opacity-75">
                        @if($room->type === 'service')
                            دردشة خاصة مع الإدارة (الدعم الفني)
                        @else
                            دردشة جماعية (الطلاب، المعلم، والإدارة)
                        @endif
                    </p>
                </div>
            </div>
            <div class="text-sm">
                <span x-show="online" class="bg-green-400 w-2 h-2 rounded-full inline-block mr-1"></span>
                <span x-text="online ? 'متصل' : 'جاري الاتصال...'"></span>
            </div>
        </div>

        <!-- Messages Area -->
        <div class="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50" id="messages-container">
            <template x-for="msg in messages" :key="msg.id">
                <div :class="msg.user_id == {{ auth()->id() }} ? 'flex justify-end' : 'flex justify-start'">
                    <div :class="msg.user_id == {{ auth()->id() }} ? 'bg-blue-100 text-right' : 'bg-white text-left'" 
                         class="max-w-xs md:max-w-md rounded-lg p-3 shadow-sm relative">
                        
                        <p class="text-xs font-bold text-gray-600 mb-1" x-text="msg.user.name + ' (' + msg.user.role_label + ')'"></p>
                        
                        <p class="text-sm" x-text="msg.content"></p>

                        <span class="text-[10px] text-gray-400 mt-1 block" x-text="formatTime(msg.created_at)"></span>
                    </div>
                </div>
            </template>
        </div>

        <!-- Input Area -->
        <div class="p-4 border-t bg-white">
            <form @submit.prevent="sendMessage" class="flex items-center space-x-2 rtl:space-x-reverse">
                <input type="text" x-model="newMessage" placeholder="اكتب رسالتك هنا..." 
                       class="flex-1 border rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
                
                <button type="submit" :disabled="sending" class="bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 disabled:opacity-50">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7"></path></svg>
                </button>
            </form>
        </div>
    </div>
</div>

<script>
function chatApp() {
    return {
        messages: @json($messages),
        newMessage: '',
        sending: false,
        online: false,
        
        init() {
            this.scrollToBottom();
            this.listenForMessages();
        },

        listenForMessages() {
            // منطق الـ Real-time باستخدام Laravel Echo
            if (typeof Echo !== 'undefined') {
                Echo.private('chat.' + {{ $room->id }})
                    .listen('.message.sent', (e) => {
                        this.messages.push(e.message);
                        this.scrollToBottom();
                    })
                    .on('connected', () => this.online = true)
                    .on('disconnected', () => this.online = false);
            }
        },

        async sendMessage() {
            if (!this.newMessage) return;
            
            this.sending = true;
            try {
                const response = await axios.post('{{ route('chat.send', $room->id) }}', {
                    content: this.newMessage
                });
                this.messages.push(response.data);
                this.newMessage = '';
                this.scrollToBottom();
            } catch (error) {
                alert('فشل إرسال الرسالة');
            } finally {
                this.sending = false;
            }
        },

        formatTime(dateStr) {
            const date = new Date(dateStr);
            return date.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
        },

        scrollToBottom() {
            setTimeout(() => {
                const container = document.getElementById('messages-container');
                if (container) {
                    container.scrollTop = container.scrollHeight;
                }
            }, 100);
        }
    }
}
</script>
@endsection

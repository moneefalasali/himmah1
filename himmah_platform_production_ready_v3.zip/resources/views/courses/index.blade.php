@extends('layouts.app')

@section('content')
<div class="bg-gray-50 min-h-screen pb-20">
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-blue-700 to-blue-900 pt-24 pb-32 px-6">
        <div class="container mx-auto text-center">
            <h1 class="text-4xl md:text-6xl font-black text-white mb-6 leading-tight">استكشف مستقبلك التعليمي</h1>
            <p class="text-xl text-blue-100 max-w-2xl mx-auto opacity-90">اختر من بين مئات الدورات المتخصصة في المناهج الجامعية والمهارات العامة مع أفضل الخبراء.</p>
        </div>
    </div>

    <div class="container mx-auto px-6 -mt-16">
        <!-- Filter Bar -->
        <div class="bg-white p-6 md:p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 mb-16 transition-all hover:shadow-blue-100/50">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div class="space-y-2">
                    <label class="block text-sm font-bold text-gray-700 px-1">نوع التعليم</label>
                    <select x-model="filters.classification" @change="applyFilters()" class="w-full border-gray-100 bg-gray-50 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 py-4 px-5 font-medium transition-all">
                        <option value="">الكل</option>
                        <option value="university">جامعي</option>
                        <option value="general">دورات عامة</option>
                    </select>
                </div>
                <div x-show="filters.classification === 'university'" class="space-y-2">
                    <label class="block text-sm font-bold text-gray-700 px-1">الجامعة</label>
                    <select x-model="filters.university_id" @change="applyFilters()" class="w-full border-gray-100 bg-gray-50 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 py-4 px-5 font-medium transition-all">
                        <option value="">اختر الجامعة...</option>
                        @foreach($universities as $uni)
                            <option value="{{ $uni->id }}">{{ $uni->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="space-y-2">
                    <label class="block text-sm font-bold text-gray-700 px-1">نوع الدورة</label>
                    <select x-model="filters.type" @change="applyFilters()" class="w-full border-gray-100 bg-gray-50 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 py-4 px-5 font-medium transition-all">
                        <option value="">الكل</option>
                        <option value="recorded">مسجل</option>
                        <option value="online">أونلاين</option>
                    </select>
                </div>
                <div class="space-y-2">
                    <label class="block text-sm font-bold text-gray-700 px-1">بحث سريع</label>
                    <div class="relative">
                        <input type="text" x-model="filters.search" @input.debounce.500ms="applyFilters()" placeholder="ابحث عن دورة..." class="w-full border-gray-100 bg-gray-50 rounded-2xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 py-4 pr-12 pl-5 font-medium transition-all">
                        <div class="absolute inset-y-0 right-0 flex items-center pr-5 pointer-events-none text-gray-400">
                            <i class="fas fa-search"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Course Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-20" id="course-container">
            @foreach($courses as $course)
                <div class="bg-white rounded-[2rem] shadow-sm border border-gray-100 overflow-hidden hover:shadow-2xl transition-all duration-500 group flex flex-col h-full">
                    <div class="relative overflow-hidden">
                        <img src="{{ $course->thumbnail_url }}" class="w-full h-64 object-cover group-hover:scale-110 transition duration-700">
                        <div class="absolute top-5 right-5 bg-white/95 backdrop-blur px-4 py-1.5 rounded-full text-xs font-black text-blue-700 shadow-lg uppercase tracking-wider">
                            {{ $course->type === 'recorded' ? 'مسجل' : 'أونلاين' }}
                        </div>
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-8">
                            <span class="text-white font-bold text-sm"><i class="fas fa-play-circle mr-2"></i> عرض التفاصيل</span>
                        </div>
                    </div>
                    <div class="p-8 flex flex-col flex-grow">
                        <div class="flex items-center justify-between mb-4">
                            <span class="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-xs font-bold">{{ $course->category->name ?? 'عام' }}</span>
                            <span class="text-gray-400 text-xs font-medium"><i class="far fa-clock mr-1"></i> {{ $course->total_duration ?? '0' }} ساعة</span>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-800 mb-4 group-hover:text-blue-600 transition-colors line-clamp-1">{{ $course->title }}</h3>
                        <p class="text-gray-500 text-sm mb-8 line-clamp-2 leading-relaxed">{{ $course->description }}</p>
                        
                        <div class="mt-auto pt-6 border-t border-gray-50 flex items-center justify-between">
                            <div class="flex flex-col">
                                <span class="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">السعر</span>
                                <div class="text-3xl font-black text-blue-600">{{ $course->price }} <span class="text-sm font-bold">ريال</span></div>
                            </div>
                            <a href="{{ route('courses.show', $course) }}" class="bg-blue-600 text-white px-8 py-3.5 rounded-2xl font-bold hover:bg-blue-700 hover:shadow-lg hover:shadow-blue-200 transition-all transform active:scale-95">
                                اشترك الآن
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</div>

<script>
let page = 1;
let loading = false;

window.onscroll = function() {
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight - 800 && !loading) {
        loadMoreCourses();
    }
};

function loadMoreCourses() {
    loading = true;
    page++;
    fetch("?page=" + page, {
        headers: { "X-Requested-With": "XMLHttpRequest" }
    })
    .then(response => response.text())
    .then(data => {
        if (data.trim().length > 0) {
            document.getElementById("course-container").insertAdjacentHTML("beforeend", data);
            loading = false;
        }
    })
    .catch(() => {
        loading = false;
    });
}
</script>
@endsection

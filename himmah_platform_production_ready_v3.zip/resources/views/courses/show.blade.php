@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- تفاصيل الكورس -->
        <div class="lg:col-span-2">
            <div class="bg-white rounded-2xl shadow-sm overflow-hidden border border-gray-100">
                <img src="{{ $course->thumbnail_url }}" class="w-full h-96 object-cover">
                <div class="p-8">
                    <div class="flex justify-between items-start mb-4">
                        <h1 class="text-3xl font-bold text-gray-800">{{ $course->title }}</h1>
                        <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-bold">
                            {{ $course->type === 'recorded' ? 'مسجل' : 'أونلاين' }}
                        </span>
                    </div>
                    <p class="text-gray-600 mb-8 text-lg leading-relaxed">{{ $course->description }}</p>
                    
                    <h3 class="text-xl font-bold mb-4 border-b pb-2">محتوى الدورة</h3>
                    <div class="space-y-3">
                        @foreach($course->lessons as $lesson)
                            <div class="flex justify-between items-center p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                                <div class="flex items-center">
                                    <i class="far fa-play-circle text-blue-600 mr-3 text-xl"></i>
                                    <span class="font-medium text-gray-700">{{ $lesson->title }}</span>
                                </div>
                                <span class="text-sm text-gray-500">{{ $lesson->duration }} دقيقة</span>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        <!-- الشريط الجانبي (Sidebar) -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-2xl shadow-sm p-6 border border-gray-100 sticky top-6">
                <div class="text-3xl font-bold text-blue-600 mb-6">{{ $course->price }} ريال</div>
                
                @if(auth()->user()->isEnrolledIn($course))
                    <div class="space-y-4">
                        <a href="{{ route('lessons.show', $course->lessons->first()) }}" class="block w-full bg-blue-600 text-white text-center font-bold py-4 rounded-xl hover:bg-blue-700 transition">
                            متابعة التعلم
                        </a>
                        <a href="{{ route('chat.course', $course) }}" class="block w-full bg-green-600 text-white text-center font-bold py-4 rounded-xl hover:bg-green-700 transition">
                            <i class="fas fa-comments mr-2"></i> دردشة الكورس الجماعية
                        </a>
                    </div>
                @else
                    <button class="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition mb-4">
                        اشترك الآن
                    </button>
                @endif

                <div class="mt-8 pt-8 border-t border-gray-100">
                    <h4 class="font-bold mb-4">هل تحتاج مساعدة؟</h4>
                    <a href="{{ route('chat.admin') }}" class="flex items-center justify-center w-full border-2 border-blue-600 text-blue-600 font-bold py-3 rounded-xl hover:bg-blue-50 transition">
                        <i class="fas fa-headset mr-2"></i> تواصل مع الدعم الفني
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

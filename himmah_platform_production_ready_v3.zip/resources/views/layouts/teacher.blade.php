<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المعلم - @yield('title')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Cairo', sans-serif; }
    </style>
    @yield('styles')
    <link rel="stylesheet" href="{{ asset("css/custom-ux.css") }}">
    <link rel="stylesheet" href="{{ asset("css/custom-ux.css") }}">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen flex">
        <!-- Sidebar -->
        <aside class="w-64 bg-indigo-900 text-white hidden md:block">
            <div class="p-6 text-2xl font-bold border-b border-indigo-800">منصة همة</div>
            <nav class="mt-6">
                <a href="{{ route('teacher.dashboard') }}" class="block py-3 px-6 hover:bg-indigo-800 {{ request()->routeIs('teacher.dashboard') ? 'bg-indigo-800' : '' }}">الرئيسية</a>
                <a href="{{ route('teacher.courses.index') }}" class="block py-3 px-6 hover:bg-indigo-800 {{ request()->routeIs('teacher.courses.*') ? 'bg-indigo-800' : '' }}">دوراتي</a>
                <a href="{{ route('teacher.sales') }}" class="block py-3 px-6 hover:bg-indigo-800 {{ request()->routeIs('teacher.sales') ? 'bg-indigo-800' : '' }}">المبيعات والأرباح</a>
                <form method="POST" action="/logout" class="mt-10">
                    @csrf
                    <button type="submit" class="w-full text-right py-3 px-6 hover:bg-red-700 text-red-200">تسجيل الخروج</button>
                </form>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1">
            <header class="bg-white shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-xl font-semibold text-gray-800">@yield('title')</h1>
                <div class="flex items-center space-x-4 space-x-reverse">
                    <span class="text-gray-600">{{ auth()->user()->name }} (معلم)</span>
                </div>
            </header>

            <div class="p-6">
                @if(session('success'))
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                        {{ session('success') }}
                    </div>
                @endif

                @yield('content')
            </div>
        </main>
    </div>
    @yield('scripts')
</body>
</html>

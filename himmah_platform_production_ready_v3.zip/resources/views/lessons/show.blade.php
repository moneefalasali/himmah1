@extends('layouts.app')

@section('title', $lesson->title)

@section('content')
<div class="container mx-auto p-4">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- مشغل الفيديو -->
        <div class="lg:col-span-2">
            <div class="bg-black rounded-xl overflow-hidden shadow-lg aspect-video relative">
                @if($lesson->video_platform === 'wasabi')
                    <!-- HLS Player (Video.js) -->
                    <link href="https://vjs.zencdn.net/7.20.3/video-js.css" rel="stylesheet" />
                    <video id="hls-player" class="video-js vjs-big-play-centered w-full h-full" controls preload="auto" data-setup='{}'>
                        <source src="{{ $lesson->hls_url }}" type="application/x-mpegURL">
                        <p class="vjs-no-js">
                            لمشاهدة هذا الفيديو، يرجى تفعيل JavaScript وتحديث المتصفح.
                        </p>
                    </video>
                    <script src="https://vjs.zencdn.net/7.20.3/video.min.js"></script>
                @elseif($lesson->video_platform === 'vimeo')
                    <iframe src="https://player.vimeo.com/video/{{ $lesson->vimeo_video_id }}" class="w-full h-full" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                @else
                    <div class="flex items-center justify-center h-full text-white">
                        <p>الفيديو غير متاح حالياً</p>
                    </div>
                @endif
            </div>

            <div class="mt-6 bg-white p-6 rounded-xl shadow-sm">
                <h1 class="text-2xl font-bold mb-2">{{ $lesson->title }}</h1>
                <p class="text-gray-600">{{ $lesson->description }}</p>
            </div>
        </div>

        <!-- قائمة الدروس -->
        <div class="lg:col-span-1">
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <div class="p-4 bg-gray-50 border-b">
                    <h3 class="font-bold">محتوى الدورة</h3>
                </div>
                <div class="divide-y max-h-[600px] overflow-y-auto">
                    @foreach($lesson->course->lessons as $l)
                        <a href="{{ route('lessons.show', $l) }}" class="flex items-center p-4 hover:bg-blue-50 transition {{ $l->id === $lesson->id ? 'bg-blue-50 border-r-4 border-blue-600' : '' }}">
                            <div class="mr-3">
                                @if($l->id === $lesson->id)
                                    <i class="fas fa-play-circle text-blue-600"></i>
                                @else
                                    <i class="far fa-play-circle text-gray-400"></i>
                                @endif
                            </div>
                            <div>
                                <p class="text-sm font-medium {{ $l->id === $lesson->id ? 'text-blue-600' : 'text-gray-700' }}">{{ $l->title }}</p>
                                <p class="text-xs text-gray-500">{{ $l->duration }} دقيقة</p>
                            </div>
                        </a>
                    @endforeach
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

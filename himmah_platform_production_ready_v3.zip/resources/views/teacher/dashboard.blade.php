@extends('layouts.app')

@section('content')
<div class="p-6 bg-gray-50 min-h-screen">
    <div class="mb-8 flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">مرحباً بك، {{ auth()->user()->name }}</h1>
            <p class="text-gray-600">إليك ملخص لأداء دوراتك التعليمية.</p>
        </div>
        <a href="{{ route('teacher.courses.create') }}" class="bg-blue-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg">
            <i class="fas fa-plus mr-2"></i> إنشاء دورة جديدة
        </a>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-gray-500 text-sm font-medium mb-2">طلابك المسجلين</h3>
            <p class="text-3xl font-bold text-gray-800">{{ $totalStudents ?? 0 }}</p>
            <div class="mt-4 text-green-500 text-sm font-bold"><i class="fas fa-arrow-up mr-1"></i> +8% هذا الشهر</div>
        </div>

        <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-gray-500 text-sm font-medium mb-2">إجمالي الأرباح</h3>
            <p class="text-3xl font-bold text-blue-600">{{ $totalEarnings ?? 0 }} ريال</p>
            <div class="mt-4 text-gray-400 text-sm font-medium">صافي الأرباح بعد العمولات</div>
        </div>

        <div class="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-gray-500 text-sm font-medium mb-2">تقييم دوراتك</h3>
            <p class="text-3xl font-bold text-yellow-500">4.8 / 5</p>
            <div class="mt-4 text-gray-400 text-sm font-medium">بناءً على 120 تقييم</div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <!-- My Courses -->
        <div class="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-lg font-bold mb-6 border-b pb-4">دوراتك التعليمية</h3>
            <div class="space-y-4">
                @forelse($courses ?? [] as $course)
                    <div class="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition">
                        <div class="flex items-center">
                            <img src="{{ $course->thumbnail_url }}" class="w-12 h-12 rounded-lg object-cover mr-4">
                            <div>
                                <h4 class="font-bold text-gray-800">{{ $course->title }}</h4>
                                <p class="text-xs text-gray-500">{{ $course->students_count }} طالب مسجل</p>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <a href="{{ route('teacher.courses.edit', $course) }}" class="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition"><i class="fas fa-edit"></i></a>
                            <a href="{{ route('chat.course', $course) }}" class="p-2 text-green-600 hover:bg-green-50 rounded-lg transition"><i class="fas fa-comments"></i></a>
                        </div>
                    </div>
                @empty
                    <p class="text-gray-500 text-sm text-center py-8">لم تقم بإنشاء أي دورات بعد.</p>
                @endforelse
            </div>
        </div>

        <!-- Recent Sales -->
        <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 class="text-lg font-bold mb-6 border-b pb-4">آخر المبيعات</h3>
            <div class="space-y-6">
                @forelse($recentSales ?? [] as $sale)
                    <div class="flex items-center justify-between">
                        <div class="flex items-center">
                            <div class="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mr-3 text-gray-600">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <p class="text-sm font-bold text-gray-800">{{ $sale->user->name }}</p>
                                <p class="text-xs text-gray-500">{{ $sale->created_at->diffForHumans() }}</p>
                            </div>
                        </div>
                        <span class="text-sm font-bold text-green-600">+{{ $sale->amount }} ريال</span>
                    </div>
                @empty
                    <p class="text-gray-500 text-sm text-center py-8">لا توجد مبيعات حديثة.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection

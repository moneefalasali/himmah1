<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AdminCourseController;
use App\Http\Controllers\Admin\AdminUniversityController;
use App\Http\Controllers\Admin\AdminSubjectController;
use App\Http\Controllers\Admin\AdminUniCourseController;
use App\Http\Controllers\Admin\AdminCategoryController;
use App\Http\Controllers\Admin\AdminUserController;
use App\Http\Controllers\Admin\AdminChatController;
use App\Http\Controllers\Admin\AdminLiveSessionController;
use App\Http\Controllers\Admin\AdminAIController;

Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    
    Route::get('/', [AdminController::class, 'index'])->name('dashboard');
    
    // الجامعات والمقررات
    Route::resource('universities', AdminUniversityController::class);
    Route::resource('subjects', AdminSubjectController::class);
    Route::resource('uni-courses', AdminUniCourseController::class);
    Route::resource('categories', AdminCategoryController::class);
    
    // الكورسات والمستخدمين
    Route::resource('courses', AdminCourseController::class);
    Route::resource('users', AdminUserController::class);
    
    // نظام الخدمات الجديد (دردشات العملاء)
    Route::get('customer-chats', [AdminChatController::class, 'index'])->name('customer-chats.index');
    Route::get('customer-chats/{room}', [AdminChatController::class, 'show'])->name('customer-chats.show');
    
    // الحصص الأونلاين والـ AI
    Route::resource('live-sessions', AdminLiveSessionController::class);
    Route::get('ai-reports', [AdminAIController::class, 'reports'])->name('ai.reports');
});

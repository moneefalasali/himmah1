<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Teacher\TeacherCourseController;
use App\Http\Controllers\Teacher\TeacherLessonController;
use App\Http\Controllers\Teacher\TeacherDashboardController;
use App\Http\Controllers\Teacher\TeacherSalesController;
use App\Http\Controllers\Teacher\TeacherQuizController;
use App\Http\Controllers\Teacher\TeacherLiveSessionController;
use App\Http\Controllers\Teacher\TeacherAIController;
use App\Http\Controllers\Teacher\TeacherVideoUploadController;

Route::middleware(['auth', 'teacher'])->prefix('teacher')->name('teacher.')->group(function () {
    
    // Dashboard
    Route::get('/', [TeacherDashboardController::class, 'index'])->name('dashboard');
    
    // Courses Management
    Route::resource('courses', TeacherCourseController::class);
    
    // Lessons Management
    Route::post('courses/{course}/lessons', [TeacherLessonController::class, 'store'])->name('lessons.store');
    Route::put('courses/{course}/lessons/{lesson}', [TeacherLessonController::class, 'update'])->name('lessons.update');
    Route::delete('courses/{course}/lessons/{lesson}', [TeacherLessonController::class, 'destroy'])->name('lessons.destroy');
    
    // Quizzes
    Route::resource('quizzes', TeacherQuizController::class);
    
    // Live Sessions
    Route::resource('live-sessions', TeacherLiveSessionController::class);
    
    // Video Upload
    Route::post('video/upload', [TeacherVideoUploadController::class, 'upload'])->name('video.upload');
    
    // Sales & Revenue
    Route::get('sales', [TeacherSalesController::class, 'index'])->name('sales');
    
    // AI Assistant
    Route::post('ai/generate', [TeacherAIController::class, 'generate'])->name('ai.generate');
});
